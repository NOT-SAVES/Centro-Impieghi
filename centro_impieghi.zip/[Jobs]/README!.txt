PER FAR FUNZIONARE LO SCRIPT DOVRETE:

INSERIRE I SEGUENTI JOB NEL DATABASE

- agricoltore (grado 1)
- elettricista (grado 1)
- boscaiolo (grado 1)

INSERIRE L ITEM LEGNA SE NON LO AVETE GIA (SCRIVETELO COME NEL SV_JOB! SENNO NON VI DARA NULLA!)

PER MAGGIORI INFO ENTRATE NEL MIO DISCOR


MI RACCOMANDO LA CARTELLA "script" dovra essere cancellata dopo aver inserito la risorsa nella vostra cartella

